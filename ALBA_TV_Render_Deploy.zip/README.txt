# ALBA TV — paketë për publikim

## Përmbajtja
- `server.js`: server Node.js që lexon M3U privatisht dhe bën proxy të transmetimeve.
- `public/index.html`: ndërfaqja e ALBA TV.
- `Albanien 3 tv.m3u`: lista burimore, ruhet vetëm në server dhe NUK shërbehet si skedar publik.

## Publikimi
Kërkohet një host që mban proces Node.js 20+ dhe lejon dalje HTTP/HTTPS drejt hostit të ofruesit IPTV.
1. Ngarko përmbajtjen e kësaj pakete në një projekt privat në host.
2. Vendos komandën e nisjes: `node server.js`.
3. Sigurohu që `Albanien 3 tv.m3u` të jetë në të njëjtën direktori me `server.js`.
4. Vendos domain-in dhe aktivizo HTTPS në panelin e hostit.
5. Testo `/health`, pastaj hap faqen kryesore dhe provo kanalet.

## Siguria
- Mos e vendos M3U në `public/`, Git publik, apo në një CDN.
- M3U përmban kredenciale/rrugë private të ofruesit. Kjo paketë e mban në anën e serverit.
- Mos e shpërnda ZIP-in publikisht; dërgoje vetëm te administratori i hostit.
- Proxy pranon vetëm ID kanalesh nga M3U dhe hostet burimore të listës; nuk pranon URL arbitrare.
- Publiko vetëm kanalet për të cilat ke të drejta rishpërndarjeje.
- Për mbrojtje më të mirë, vendos autentikim/abonime, kufij përdorimi dhe monitorim para se ta hapësh për publik të pakufizuar.

## Kufizime që duhen ditur
Kjo është paketë e gatshme për deploy, jo faqe e publikuar. Nuk mund të krijoj domain/hosting pa hyrjen ose bashkëpunimin tënd me ofruesin e hosting-ut.
Proxy zgjidh CORS vetëm në shfletues; nuk mund të garantojë që ofruesi pranon lidhje nga IP e serverit, që stream-i është MPEG-TS i përshtatshëm për mpegts.js, ose që ofruesi lejon shumë shikues njëkohësisht. Këto duhen provuar në hostin real.
Për publik me shumë shikues nevojitet marrëveshje me ofruesin për kapacitet, bandwidth dhe rishpërndarje. Mos përdor një llogari personale IPTV si burim publik pa miratimin e qartë të ofruesit.
