// ALBA TV private-source streaming gateway. Node.js 20+
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { Readable } = require('node:stream');

const ROOT = __dirname;
const PUBLIC = path.join(ROOT, 'public');
const PLAYLIST = path.join(ROOT, 'Albanien 3 tv.m3u');
const PORT = Number(process.env.PORT || 3000);

function parseM3U(text) {
  const lines = text.split(/\r?\n/).map(x => x.trim()).filter(Boolean);
  const out = [];
  for (let i = 0; i < lines.length; i++) {
    if (!lines[i].startsWith('#EXTINF:')) continue;
    const meta = lines[i];
    const url = lines.slice(i + 1).find(x => !x.startsWith('#'));
    if (!url) continue;
    const name = (meta.split(',').slice(1).join(',') || `Kanal ${out.length + 1}`).replace('|ALB|','').trim();
    const group = (meta.match(/group-title="([^"]*)"/i) || [])[1] || 'Të tjera';
    const logo = (meta.match(/tvg-logo="([^"]*)"/i) || [])[1] || '';
    out.push({ id: out.length, name, group, logo, url });
  }
  return out;
}
let channels;
try {
  channels = parseM3U(fs.readFileSync(PLAYLIST, 'utf8'));
  if (!channels.length) throw new Error('Playlist is empty');
} catch (e) {
  console.error('Cannot load private M3U:', e.message);
  process.exit(1);
}
const allowedHosts = new Set(channels.map(c => {
  try { return new URL(c.url).hostname; } catch { return ''; }
}).filter(Boolean));

const mime = { '.html':'text/html; charset=utf-8', '.css':'text/css; charset=utf-8', '.js':'text/javascript; charset=utf-8', '.svg':'image/svg+xml', '.png':'image/png', '.ico':'image/x-icon' };
function send(res, code, body, type='text/plain; charset=utf-8') {
  res.writeHead(code, {'Content-Type':type,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});
  res.end(body);
}
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  if (url.pathname === '/health') return send(res,200,'ok');
  if (url.pathname === '/api/channels') {
    const safe = channels.map(({id,name,group,logo}) => ({id,name,group,logo}));
    return send(res,200,JSON.stringify({channels:safe}), 'application/json; charset=utf-8');
  }
  const match = url.pathname.match(/^\/stream\/(\d+)$/);
  if (match) {
    const channel = channels[Number(match[1])];
    if (!channel) return send(res,404,'Channel not found');
    let upstream;
    try { upstream = new URL(channel.url); } catch { return send(res,502,'Invalid source URL'); }
    if (!['http:','https:'].includes(upstream.protocol) || !allowedHosts.has(upstream.hostname)) return send(res,403,'Source not allowed');
    const controller = new AbortController();
    res.on('close', () => { if (!res.writableEnded) controller.abort(); });
    try {
      const headers = {'User-Agent':'VLC/3.0 ALBA-TV-Authorized-Player','Accept':'*/*'};
      if (req.headers.range) headers.Range = req.headers.range;
      const upstreamRes = await fetch(upstream, {headers, redirect:'follow', signal:controller.signal});
      if (!upstreamRes.ok && upstreamRes.status !== 206) {
        return send(res, upstreamRes.status, `Upstream error: ${upstreamRes.status}`);
      }
      const outHeaders = {
        'Content-Type': upstreamRes.headers.get('content-type') || 'video/mp2t',
        'Cache-Control':'no-store',
        'Access-Control-Allow-Origin':'*',
        'X-Content-Type-Options':'nosniff'
      };
      for (const h of ['content-length','content-range','accept-ranges']) {
        const v = upstreamRes.headers.get(h); if (v) outHeaders[h] = v;
      }
      res.writeHead(upstreamRes.status, outHeaders);
      if (upstreamRes.body) Readable.fromWeb(upstreamRes.body).pipe(res);
      else res.end();
    } catch (e) {
      if (!res.headersSent) send(res,502,'Stream unavailable. Check provider access and server logs.');
      else res.destroy();
    }
    return;
  }
  let file = url.pathname === '/' ? 'index.html' : decodeURIComponent(url.pathname).replace(/^\/+/, '');
  const full = path.resolve(PUBLIC, file);
  if (!full.startsWith(PUBLIC + path.sep) && full !== path.join(PUBLIC,'index.html')) return send(res,403,'Forbidden');
  fs.readFile(full, (err, data) => {
    if (err) return send(res,404,'Not found');
    res.writeHead(200, {'Content-Type':mime[path.extname(full)] || 'application/octet-stream','Cache-Control':'no-cache','X-Content-Type-Options':'nosniff'});
    res.end(data);
  });
});
server.listen(PORT, '0.0.0.0', () => console.log(`ALBA TV running on port ${PORT}; ${channels.length} channels loaded.`));
